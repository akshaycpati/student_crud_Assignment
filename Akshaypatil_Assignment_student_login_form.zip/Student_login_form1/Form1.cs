﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_login_form1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-F9VF0EN\\SQLEXPRESS;Initial Catalog=Student;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            string Name = textBox1.Text, Language = comboBox1.Text, Email = textBox2.Text,Gender="";
            if(radioButton1.Checked==true) { Gender = "Male"; } else { Gender = "Female"; }
            DateTime DOB = DateTime.Parse(dateTimePicker1.Text);
            con.Open();
            SqlCommand c = new SqlCommand("exec Savestudent_sp'" +Name+ "','" + DOB + "','" + Email + "','" + Gender + "','" + Language + "'",con);
            c.ExecuteNonQuery();
            MessageBox.Show("Successfully Saved...");
            GetstudentList();
        }
        void GetstudentList()
        {
            SqlCommand c = new SqlCommand("exec Liststudent_sp", con);
            SqlDataAdapter sd = new SqlDataAdapter(c);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void Form1_Load(object sender,EventArgs e)
        {
            GetstudentList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //clear
            string Name = textBox1.Text;
           con.Open();
            SqlCommand c = new SqlCommand("exec Clearstudent_sp'" + Name + "'", con);
            c.ExecuteNonQuery();
            MessageBox.Show("Successfully Cleard...");
            GetstudentList();
        }
    }
}
